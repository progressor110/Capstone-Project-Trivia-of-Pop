//
//  CategoryFetcher.swift
//  pop-trivia
//
//  Created by Marcus Ezell on 11/23/25.
//
import Foundation

class CategoryFetcher{
    //    let urlSession: URLSession.shared
    
    struct bookResponse: Decodable {
        let dataResults : [MyDataResult]
        let status : String
    }
    struct gameResponse: Decodable {
        let dataResults : [MyDataResult]
        let status : String
    }
    
    
    
//    func getUrlForMovie() -> URL? {//geo was not an element given for this api. Please help.
//        let baseUrlString = "https://serpapi.com/search.json"
//        let apiKey: String =  "1b925446437cb1f019a9e0631e2d5e045911073fd6fee3e16a71aae0288c8116"
//        let movieUrl = URL(string: "\(baseUrlString)?engine=google_play_movies&movies_category=FAMILY&age=AGE_RANGE1&gl=us&hl=en&api_key=\(apiKey)")
//       // "thumbnail": "https://play-lh.googleusercontent.com/kdnI5f-9TYbNH-HdaPjO39yS3mWB0G4ULJgnLX3ElY1TT8DoVZsEjh54QSRQdN58fgEt=s256-rw"
//        return movieUrl
//    }
//    func getUrlForBook() -> URL? {
//        let baseUrlString = "https://serpapi.com/search.json"
//        let apiKey: String =  "1b925446437cb1f019a9e0631e2d5e045911073fd6fee3e16a71aae0288c8116"
//        let bookUrl = URL(string: "\(baseUrlString)?engine=google_play_books&books_category=coll_1690&gl=us&hl=en&api_key=\(apiKey)")
//        return bookUrl
//    }
//    func getUrlForGame() -> URL? {
//        let baseUrlString = "https://serpapi.com/search.json"
//        let apiKey: String =  "1b925446437cb1f019a9e0631e2d5e045911073fd6fee3e16a71aae0288c8116"
//        let gameUrl = URL(string: "\(baseUrlString)?engine=google_play_games&next_page_token=EAUangEIBRDg-tChARDuqqitDBD86Kn2BxCDgr_OBxCI1q33Ahjzwd3oDhiC2LayDhi704ttGKe69KMEGMqbv7EKGL3zhpQHGPiL7IQDGPPuotgLGIDfxOcLGJbX764BGM_QxWoYxbz-1wsYv5mhxwMY4aXcmQwYiM-TnAMY_qOc5wgY7Oyg6gsqGGVHWDd3WHJ3eEJyUFFhQ3RYaW03M2c9PQ&gl=us&hl=en&api_key=\(apiKey)")
//        return gameUrl
//    }
    
    struct MyDataResult: Decodable {
            let title: String?
            let thumbnail: String?
        }
    struct movieResponse: Decodable {
            let dataResults : [MyDataResult]
            
        }
    func getMovieData(from movieUrl: String){
        let movieTask = URLSession.shared.dataTask(with: URL(string:movieUrl)!, completionHandler: { data, response, error in
            guard let data = data, error == nil else {
                print("Error fetching data: \(error!)")
                return
            }
            var movieResult: movieResponse?
            do {
                movieResult = try JSONDecoder().decode(movieResponse.self, from: data)
            }
            catch {
                print("Error parsing JSON: \(error.localizedDescription)")
            }
            
            guard let movieJson = movieResult else {
                return
            }
            print(movieJson)
            
        });movieTask.resume()
    }
    
    func getBookData(from bookUrl: String){
        let bookTask = URLSession.shared.dataTask(with: URL(string:bookUrl)!, completionHandler: { data, response, error in
            guard let data = data, error == nil else {
                print("Error fetching data: \(error!)")
                return
            }
            var bookResult: bookResponse?
            do {
                bookResult = try JSONDecoder().decode(bookResponse.self, from: data)
            }
            catch {
                print("Error parsing JSON: \(error.localizedDescription)")
            }
            
            guard let bookJson = bookResult else {
                return
            }
            print(bookJson.status)
            
        })
        bookTask.resume()
    }
    
    func getGameData(from gameUrl: String){
        let gameTask = URLSession.shared.dataTask(with: URL(string:gameUrl)!, completionHandler: { data, response, error in
            guard let data = data, error == nil else {
                print("Error fetching data: \(error!)")
                return
            }
            var gameResult: gameResponse?
            do {
                gameResult = try JSONDecoder().decode(gameResponse.self, from: data)
            }
            catch {
                print("Error parsing JSON: \(error.localizedDescription)")
            }
            
            guard let gameJson = gameResult else {
                return
            }
            print(gameJson.status)
            
        })
        gameTask.resume()
    }
    
}
