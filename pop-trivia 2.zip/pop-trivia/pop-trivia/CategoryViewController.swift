//
//  ViewController.swift
//  pop-trivia
//
//  Created by Marcus Ezell on 11/10/25.
//

import UIKit

enum category: String, CaseIterable {
    case film = "film"
    case book = "book"
    case controller = "game"
    case correct = "Yes"
    case incorrect = "No"
}

class CategoryViewController: UIViewController {
    
    @IBOutlet weak var filmButton: UIButton!
    
    @IBOutlet weak var bookButton: UIButton!
    
    @IBOutlet weak var gameButton: UIButton!
    
    var fetcher = CategoryFetcher()
    
    @IBAction func didPressMovieButton(_ sender: Any?) {
        //String = "film"
        
//        fetcher.getMovieData() {
//            result in
            self.performSegue(withIdentifier: "toChoiceViewController", sender: "What quote from below is from the movie Alice in Wonderland?")
        
        
    }
    
    @IBAction func didPressBookButton(_ sender: Any?) {
        //String = "book"
        self.performSegue(withIdentifier: "toChoiceViewController", sender: "What quote from below is from the book Hatchet?")
    }
    
    @IBAction func didPressGameButton(_ sender: Any?) {
        //String = "controller"
        self.performSegue(withIdentifier: "toChoiceViewController", sender: "When did the game Geometry Dash Lite come out?")
    }
    
    protocol dataCatcher {
        var thumbnail: String {get set}
    }
    struct movies : dataCatcher{//Data fetched for movie category.
                var thumbnail: String
            }
            
    struct books : dataCatcher{//Data fetchd for the book category.
                var thumbnail: String
            }
            
    struct games : dataCatcher{//Data fetched for the game category.
                var thumbnail: String
            }
            
    
    var movieUrl: URL?
    var bookUrl: URL?
    var gameUrl: URL?
//    func getUrlForMovie(movies: String) -> URL? {
        
//        let movieUrl = URL(string: "https://serpapi.com/search?engine=google_play_movies\(movies)")
        
//        return movieUrl
    //}
//    func performSegue(withIdentifier: "toMovieTriviaViewController", sender: Any?) {
//            if let didTapCategoryButton = sender as? UIButton {
//                let chosenCategory = filmButton.destination as? ChoiceViewController
//            }
//            
//        }
//    func getUrlForBooks(books: String) -> URL? {
//            let bookUrl = URL(string: "https://serpapi.com/search?engine=google_play_books\(books)")
//            let bookApiKey = "1b925446437cb1f019a9e0631e2d5e045911073fd6fee3e16a71aae0288c8116"
//            return bookUrl
//        }
//    
//    func getUrlForGames(games: String) -> URL? {
//            let gameUrl = URL(string: "https://serpapi.com/search?engine=google_play_games\(games)")
//            let gameApiKey = "1b925446437cb1f019a9e0631e2d5e045911073fd6fee3e16a71aae0288c8116"
//            return gameUrl
//        }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let dest = segue.destination as? ChoiceViewController {
            dest.sentValue = sender as! String
        }
                //            if let categChoice = category(rawValue: .film) as? String {
                //                performSegue(withIdentifier: <#T##String#>, sender: <#T##Any?#>)
                //            }
                //            if let genreChoice = sender as? String {
                //            }
                //            guard segue.destination is ChoiceViewController else { return }
        }
//    override func perform(withIdentifier identifier: String, sender: Any!) {
//        
//    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        _ = Genre(film: "toFilmTrivia", book: "toBookTrivia", controller: "toGameTrivia")
        
    }
    
    class Genre{
        var film: String
        let book: String
        let controller: String
        
        init(film: String, book: String, controller: String) {
            self.film = film
            self.book = book
            self.controller = controller
        }
    }
    
    
    
    
    
    
//    var triviaChoice: [genre]{
//        switch self{
//        self.film : String
//        self.book : String
//        self.controller : String
//        }
//    }
    
    
    
    
        
        
    
}
