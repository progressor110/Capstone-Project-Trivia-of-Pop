//
//  ChoiceViewController.swift
//  pop-trivia
//
//  Created by Marcus Ezell on 11/12/25.
//

import Foundation
import UIKit

class ChoiceViewController: UIViewController {
    
//At least one Enum
    enum choice: String{
        case correct = "correct"
        case incorrect = "incorrect"
    }

//At least one protocol
    protocol QuestionMaker{
        var question: String {get set}
        var choiceOne: String {get set}
        var choiceTwo: String {get set}
        var choiceThree: String {get set}
    }
    //Struct(s) that can possibly go with a protocol for question layout for each category
        struct MovieQestion: QuestionMaker{
            var question: String = "What quote from below is from the movie Jurrassic Park?"
            var choiceOne: String = "Curiouser and curiouser!"
            var choiceTwo: String = "You're gonna need a bigger boat."
            var choiceThree: String = "Everyone... remain... calm."
        }
        struct BookQuestion: QuestionMaker{
            var question: String = "What quote from below is from the book Hatchet?"
            var choiceOne: String = "May the odds be ever in your favor."
            var choiceTwo: String = "You are your greatest asset."
            var choiceThree: String = "One does not simply walk into Mordor..."
        }
        struct GameQuestion: QuestionMaker{
            var question: String = "When did the game Geometry Dash Lite come out?"
            var choiceOne: String = "1993"
            var choiceTwo: String = "2003"
            var choiceThree: String = "2013"
        }
//Site that helped me figure out how to create protocol: https://www.tutorialspoint.com/swift/swift_protocols.htm
    
//Variables for the rest of the code
    var userResult: choice = .correct
    var categorySelected: category = .film
    var correctAnswer: Int = 0
    var successChoice: category = .correct
    var failureChoice: category = .incorrect
    

//    struct entertainmentQuestion{// Question Layout for each genre.
//            var question: String
//            var choiceOne: String
//            var choiceTwo: String
//            var choiceThree: String
//        }
    
    
//At least one Closure
    let rightWrong = {(answer: Int, result: choice)-> choice in
        if answer == 0{
            let result = choice.correct
            return result
        }
        else{
            let result = choice.incorrect
            return result
        }
    }
    
    //IBOutlet and Action Buttons
    @IBAction func didTapChoice(_ sender: UIButton) {
        sender.tag = correctAnswer
        if sender.tag == correctAnswer {
            userResult = rightWrong(correctAnswer, userResult)
            //Prints out this answer being correct.
            self.performSegue(withIdentifier: "toResultsViewController", sender: "Correct!")
        }
        else{
            userResult = rightWrong(correctAnswer, userResult)
             //Prints out this answer being incorrect.
            self.performSegue(withIdentifier: "toResultsViewController", sender: "Incorrect!")
        }
        
    }
    
    
    @IBOutlet weak var apiThumbnail: UIImageView!
    
    @IBOutlet weak var Question: UILabel!
    
    @IBOutlet weak var choice1: UIButton!
    
    @IBOutlet weak var choice2: UIButton!
    
    @IBOutlet weak var choice3: UIButton!
    
    var thumbnailURL: String?
    func loadThumbnail() {
            guard let urlString = thumbnailURL, let url = URL(string: urlString) else { return }

            URLSession.shared.dataTask(with: url) { data, _, error in
                guard let data = data, error == nil else { return }

                DispatchQueue.main.async {
                    self.apiThumbnail.image = UIImage(data: data)
                }
            }.resume()
        }

//    @IBAction func didTapChoice(tapped:UIButton){
//        if tapped == true{
//            if rightWrong(tapped) == true{
//                performSegue(withIdentifier: "ResultViewController", sender: (Any).self)
//            }
//        }
        //if selected choice is correct...
            //Segue into to the congrats screen.
        //else
            //Segue to the "Try again" screen.
//        dismiss(animated: true)
        
//    }
    var sentValue = ""
    //ViewDidLoad Section
    override func viewDidLoad() {
        super.viewDidLoad()
        let movieQ = MovieQestion()
        let bookQ = BookQuestion()
        let gameQ = GameQuestion()
        //if the filmButton is tapped...
            //The questions and answers will be about movies.
        Question.text = sentValue
        if Question.text == "What quote from below is from the movie Alice in Wonderland?"{
                categorySelected = .film
                loadThumbnail()
                choice1.setTitle(movieQ.choiceOne, for: .normal)
                choice2.setTitle(movieQ.choiceTwo, for: .normal)
                choice3.setTitle(movieQ.choiceThree, for: .normal)
                correctAnswer = 0
            }
        
        //else if the bookButton is tapped...
            //The questions and answers will be about books.
        else if Question.text == "What quote from below is from the book Hatchet?"{
            categorySelected = .book
            loadThumbnail()
            choice1.setTitle(bookQ.choiceOne, for: .normal)
            choice2.setTitle(bookQ.choiceTwo, for: .normal)
            choice3.setTitle(bookQ.choiceThree, for: .normal)
            correctAnswer = 0
        }
        //else if the gameButton is tapped...
            //The questions and answers will be about games.
        else if Question.text == "When did the game Geometry Dash Lite come out?"{
            categorySelected = .controller
            loadThumbnail()
            choice1.setTitle(gameQ.choiceOne, for: .normal)
            choice2.setTitle(gameQ.choiceTwo, for: .normal)
            choice3.setTitle(gameQ.choiceThree, for: .normal)
            correctAnswer = 0
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.destination is ResultsViewController else {return}
        if userResult == .correct{
            //Congrats screen
            let resultDestinationVC = segue.destination as! ResultsViewController
            resultDestinationVC.resultText = "Congrats! You got it right!"
        }
        else if userResult == .incorrect{
            let resultDestinationVC = segue.destination as! ResultsViewController
            resultDestinationVC.resultText = "Oops! You got it right! Wanna try again?"
        }
        
        //If the button is success.. then resultsVC show congrats screen
        //If the button is
        //resultsViewController.didTapChoice(tapped: <#T##Bool#>) = nil
    }
    
    
    
    
    

}
