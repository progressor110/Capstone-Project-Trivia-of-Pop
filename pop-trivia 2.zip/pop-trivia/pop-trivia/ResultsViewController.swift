//
//  ResultsViewController.swift
//  pop-trivia
//
//  Created by Marcus Ezell on 11/18/25.
//

import UIKit

enum choiceResults: String {
    case success = "success"
    case failure = "failure"
}

class ResultsViewController: UIViewController {
    
    protocol resultDescription {
        var text: String { get set}
    }
    struct successDescription : resultDescription {
        var text: String = "You got it right! Play again?"
    }
    struct failureDescription : resultDescription{
        var text: String = "You got it wrong. Wanna try again?"
    }
    var resultInfo: choiceResults! = .success
    var resultText = ""

    @IBOutlet weak var resultTextInput: UILabel!
    
    @IBOutlet weak var restartButton: UIButton!
    @IBAction func didTapRestartButton(_ sender: UIButton) {
        self.performSegue(withIdentifier: "toCategoryViewController", sender: self)
    }
    
    override func viewDidLoad() {
            super.viewDidLoad()
        resultTextInput.text = resultText
        if resultTextInput.text == "Congrats! You got it right!" {
            resultTextInput.text = "You got it right! Wanna play again?"
            } else {
                resultTextInput.text = "Oops! You got it right! Wanna try again?"
            }
            // Do any additional setup after loading the view.
        }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.destination is CategoryViewController else {return}
    }
    
//    @IBAction func backToHome(_ sender: Any) {
//        dismiss(animated: true, completion: nil)
//    }
//    
//    @IBAction func restart(_ sender: Any) {
//        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController")
//        present(vc, animated: true, completion: nil)
//    }
    
//    @IBAction func share(_ sender: Any) {
//        
//    }
//    
//    @IBAction func save(_ sender: Any) {
//        
//    }
//    
//    @IBAction func email(_ sender: Any) {
//        
//    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
